package shared;

import shared.hibernate.HibernateUtil;
import shared.hibernate.PlayerDAO;
import shared.hibernate.SquadDAO;
import shared.model.Player;
import shared.model.Squad;
import shared.model.Status;

public class Main {
    public static void main(String[] args) {
        PlayerDAO playerDAO = new PlayerDAO();
        SquadDAO squadDAO = new SquadDAO();

        // Create a new player
        Player player = new Player();
        player.setMacAddress("00:1A:2B:3C:4D:5E");
        player.setUsername("player1");
        player.setXP(1000);
        player.setStatus(Status.online);
        playerDAO.savePlayer(player);

        // Create a new squad
        Squad squad = new Squad();
        squad.setName("Squad1");
        squad.setOwner(player);
        squadDAO.saveSquad(squad);

        // Add player to squad
        player.setSquad(squad);
        squad.addMember(player);
        playerDAO.updatePlayer(player);
        squadDAO.updateSquad(squad);

        // Retrieve and update a player
        Player retrievedPlayer = playerDAO.getPlayerById(player.getId());
        if (retrievedPlayer != null) {
            retrievedPlayer.setUsername("updatedPlayer1");
            playerDAO.updatePlayer(retrievedPlayer);
        }

        // Retrieve and update a squad
        Squad retrievedSquad = squadDAO.getSquadById(squad.getId());
        if (retrievedSquad != null) {
            retrievedSquad.setName("updatedSquad1");
            squadDAO.updateSquad(retrievedSquad);
        }

        // Retrieve all players
        for (Player p : playerDAO.getAllPlayers()) {
            System.out.println(p.getUsername());
        }

        // Retrieve all squads
        for (Squad s : squadDAO.getAllSquads()) {
            System.out.println(s.getName());
        }

        // Delete a player
        playerDAO.deletePlayer(player.getId());

        // Delete a squad
        squadDAO.deleteSquad(squad.getId());

        // Shutdown Hibernate
        HibernateUtil.shutdown();
    }
}