package shared.model;

public enum NotificationType {
    JOIN, MONOMACHIA, COLOSSEUM, SUMMON, SIMPLE_MESSAGE;
}
