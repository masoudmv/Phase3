package shared.model;

public enum Status {
    offline, online, busy;
}
