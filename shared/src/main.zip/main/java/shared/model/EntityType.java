package shared.model;

public enum EntityType {
    trigorath, squarantine, epsilon, bullet, collectible, simplePolygon,
    babyEpsilon, laser, orb, archmire,
    babyArchmire, barricados, necropick, nonrigidBullet;
}
