package shared.model;

public enum Skill{
    palioxis, adonis, gefjon;
}
