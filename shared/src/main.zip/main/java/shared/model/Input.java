package shared.model;

public enum Input {
    move_up, move_down, move_left, move_right,
    shoot_bullet, open_shop, activate_ability, activate_skill;

}
